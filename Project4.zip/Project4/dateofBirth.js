$(document).ready(function(){

$( function() {
  $( "#dob" ).datepicker();
} );

});
